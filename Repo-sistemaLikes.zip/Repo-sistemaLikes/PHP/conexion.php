<?php
$servidor="localhost";
$usuario="root";
$contra="";
$base="web_gym";
$cnx=mysqli_connect($servidor,$usuario,$contra,$base) or die("No se ha podido conectar a la base de datos");
?>